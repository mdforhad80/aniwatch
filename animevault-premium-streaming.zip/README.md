# AnimeVault - Premium Anime Streaming Platform

A modern, premium anime streaming website built with HTML5, CSS3, and Vanilla JavaScript. Deployable on GitHub Pages and Cloudflare Pages.

## Features

- **Dynamic Anime Discovery**: Powered by Jikan API (MyAnimeList)
- **User Authentication**: Firebase Auth with Email/Password and Google Sign-In
- **Personal Library**: Bookmarks, Favorites, Watch History, Continue Watching
- **HD Streaming**: Integrated with megaplay.buzz streaming service
- **Responsive Design**: Mobile-first, works on all devices
- **PWA Support**: Installable as a Progressive Web App
- **Cinematic UI**: Glassmorphism, neon glows, particle effects, smooth animations

## Pages

| Page | Description |
|------|-------------|
| `index.html` | Homepage with hero slider, trending, new releases, upcoming |
| `anime.html?id=ID` | Dynamic anime details with episodes, characters, trailer |
| `watch.html?id=ID&ep=1` | Video player with server selector, auto-next, keyboard shortcuts |
| `search.html` | Advanced search with filters, infinite scroll |
| `profile.html` | User profile with watch history, favorites, bookmarks |
| `schedule.html` | Weekly anime airing schedule |
| `login.html` / `signup.html` | Authentication pages |
| `creator.html` | About page with credits |

## Setup

### 1. Firebase Configuration

Edit `assets/js/auth.js` and replace the firebaseConfig with your own:

```javascript
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "your-project.firebaseapp.com",
    projectId: "your-project-id",
    storageBucket: "your-project.appspot.com",
    messagingSenderId: "123456789",
    appId: "your-app-id"
};
```

### 2. Deploy to GitHub Pages

```bash
# Create a new repository on GitHub
# Push all files to the repository
# Go to Settings > Pages
# Select source as main branch
# Your site will be live at https://yourusername.github.io/animevault
```

### 3. Deploy to Cloudflare Pages

```bash
# Connect your GitHub repository to Cloudflare Pages
# Or drag and drop the folder to Cloudflare Pages dashboard
# Build command: (none - static site)
# Output directory: /
```

## Architecture

```
/
├── index.html              # Homepage
├── anime.html              # Anime details (dynamic)
├── watch.html              # Video player (dynamic)
├── search.html             # Search & filters
├── profile.html            # User profile
├── schedule.html           # Airing schedule
├── login.html / signup.html# Auth pages
├── creator.html            # About page
├── assets/
│   ├── css/
│   │   ├── main.css        # Core styles, variables, layout
│   │   ├── components.css  # Component-specific styles
│   │   ├── player.css      # Video player styles
│   │   └── auth.css        # Auth page styles
│   └── js/
│       ├── app.js          # Homepage logic
│       ├── api.js          # Jikan API wrapper
│       ├── auth.js         # Firebase authentication
│       ├── search.js       # Search functionality
│       ├── ui.js           # UI utilities & effects
│       ├── storage.js      # Data management (Firestore + localStorage)
│       ├── anime-page.js   # Anime details page
│       ├── watch-page.js   # Video player page
│       ├── search-page.js  # Search page
│       ├── profile-page.js # Profile page
│       └── schedule-page.js# Schedule page
├── sw.js                   # Service Worker (PWA)
└── manifest.json           # PWA manifest
```

## API Integration

- **Jikan API v4**: `https://api.jikan.moe/v4`
- **Streaming**: `https://megaplay.buzz/stream/mal/{MAL_ID}/{EPISODE}/{sub|dub}`

## Keyboard Shortcuts (Watch Page)

| Key | Action |
|-----|--------|
| `F` | Fullscreen |
| `T` | Theater Mode |
| `N` | Next Episode |
| `Space` | Play/Pause |
| `← / →` | Seek (requires player API) |

## Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## License

MIT License - Free for personal and commercial use.

## Credits

- [Jikan API](https://jikan.moe) - Anime data
- [MyAnimeList](https://myanimelist.net) - Database source
- [Firebase](https://firebase.google.com) - Auth & Database
- [Font Awesome](https://fontawesome.com) - Icons
- [Google Fonts](https://fonts.google.com) - Typography
